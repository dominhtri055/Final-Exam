# Final_2024

- Make sure you have posted a link to your repo inside the Brightspace dropbox.   

- Watch the video closely and refer to the pdf for extra hints and instructions.      

- Once you are finished with the test, make sure that you commit and push all of your work.
  Anything not pushed to the repo will not be graded.    

- I will not be accepting anything late. If your work is not in the repo, you will receive a zero. for the test.   

- Check that your work is in the repo, by clicking the repo link, the same one you pasted in Brightspace, and viewing the contents in GitHub.    

- If you dont see YOUR files, they were not pushed correctly.    

  